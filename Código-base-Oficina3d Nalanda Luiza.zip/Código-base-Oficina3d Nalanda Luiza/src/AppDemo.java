import java.util.Scanner;

/**
 * Demonstração interativa do App com opções 7 e 8 pré-configuradas
 */
public class AppDemo {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in, "UTF-8");
        
        System.out.println("╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║         DEMONSTRAÇÃO INTERATIVA DO APP - RECORTE               ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝\n");
        
        System.out.println("Escolha uma opção:");
        System.out.println("1 - Testar RECORTE POR ID (opção 8)");
        System.out.println("2 - Testar RECORTE POR DESCRIÇÃO (opção 7)");
        System.out.println("0 - Sair");
        System.out.print("\nDigite sua escolha: ");
        
        int escolha = Integer.parseInt(teclado.nextLine());
        
        if (escolha == 1) {
            testarRecortePorId(teclado);
        } else if (escolha == 2) {
            testarRecortePorDescricao(teclado);
        } else {
            System.out.println("Saindo...");
        }
        
        teclado.close();
    }
    
    static void testarRecortePorId(Scanner teclado) {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║ TESTE: RECORTE POR ID                                           ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝\n");
        
        System.out.println("Carregando produtos por ID...");
        App.CarregamentoResult<Integer> res = App.lerProdutosMedido("produtos.txt", p -> p.idProduto, false);
        
        if (res.arvore == null) {
            System.out.println("Falha ao carregar produtos!");
            return;
        }
        
        System.out.println("✓ " + res.quantidade + " produtos carregados em " + res.tempoInsercaoMs + " ms\n");
        
        System.out.print("Digite o ID inicial: ");
        int idInicio = Integer.parseInt(teclado.nextLine());
        
        System.out.print("Digite o ID final: ");
        int idFim = Integer.parseInt(teclado.nextLine());
        
        System.out.println("\n→ Recortando intervalo [" + idInicio + ", " + idFim + "]...\n");
        
        Lista<Produto> resultado = res.arvore.recortar(idInicio, idFim);
        System.out.println(resultado);
    }
    
    static void testarRecortePorDescricao(Scanner teclado) {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║ TESTE: RECORTE POR DESCRIÇÃO                                    ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝\n");
        
        System.out.println("Carregando produtos por descrição...");
        App.CarregamentoResult<String> res = App.lerProdutosMedido("produtos.txt", p -> p.descricao, false);
        
        if (res.arvore == null) {
            System.out.println("Falha ao carregar produtos!");
            return;
        }
        
        System.out.println("✓ " + res.quantidade + " produtos carregados em " + res.tempoInsercaoMs + " ms\n");
        
        System.out.print("Digite a descrição inicial (ex: 'Papel'): ");
        String descInicio = teclado.nextLine();
        
        System.out.print("Digite a descrição final (ex: 'Papel para'): ");
        String descFim = teclado.nextLine();
        
        System.out.println("\n→ Recortando intervalo [\"" + descInicio + "\", \"" + descFim + "\"]...\n");
        
        Lista<Produto> resultado = res.arvore.recortar(descInicio, descFim);
        
        // Mostrar resultado limitado se muito grande
        String[] linhas = resultado.toString().split("\n");
        int limite = Math.min(30, linhas.length);
        for (int i = 0; i < limite; i++) {
            System.out.println(linhas[i]);
        }
        
        if (linhas.length > 30) {
            System.out.println("\n... (" + (linhas.length - 30) + " produtos adicionais)");
        }
    }
}
