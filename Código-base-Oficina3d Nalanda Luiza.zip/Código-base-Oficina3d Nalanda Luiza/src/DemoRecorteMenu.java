/**
 * Demonstração interativa das opções 7 e 8 do menu
 * Simula o fluxo de carregamento e recorte via menu
 */
public class DemoRecorteMenu {
    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║          DEMONSTRAÇÃO: RECORTE VIA MENU (OPÇÕES 7 E 8)         ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝\n");
        
        // ========== DEMONSTRAÇÃO OPÇÃO 8: RECORTE POR ID ==========
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ OPÇÃO 8: RECORTAR POR ID                                        │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘\n");
        
        System.out.println("Passo 1: Carregar produtos (escolher opção 2 no menu principal)");
        System.out.println("Passo 2: Escolher opção 8 - Recortar por ID");
        System.out.println("Passo 3: Informar ID inicial e final\n");
        
        System.out.println("Exemplo prático: Recortar IDs de 10050 a 10060\n");
        
        App.CarregamentoResult<Integer> resId = App.lerProdutosMedido("produtos.txt", p -> p.idProduto, false);
        ABB<Integer, Produto> abbId = resId.arvore;
        
        int idInicio = 10050;
        int idFim = 10060;
        
        System.out.println("→ Recortando intervalo [" + idInicio + ", " + idFim + "]...\n");
        Lista<Produto> resultadoId = abbId.recortar(idInicio, idFim);
        System.out.println(resultadoId);
        
        // ========== DEMONSTRAÇÃO OPÇÃO 7: RECORTE POR DESCRIÇÃO ==========
        System.out.println("\n┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ OPÇÃO 7: RECORTAR POR DESCRIÇÃO                                 │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘\n");
        
        System.out.println("Passo 1: Carregar produtos (escolher opção 1 no menu principal)");
        System.out.println("Passo 2: Escolher opção 7 - Recortar por Descrição");
        System.out.println("Passo 3: Informar descrição inicial e final (em ordem alfabética)\n");
        
        System.out.println("Exemplo prático: Recortar de \"Envelope\" a \"Envelope Vermelho\"\n");
        
        App.CarregamentoResult<String> resDesc = App.lerProdutosMedido("produtos.txt", p -> p.descricao, false);
        ABB<String, Produto> abbDesc = resDesc.arvore;
        
        String descInicio = "Envelope";
        String descFim = "Envelope Vermelho";
        
        System.out.println("→ Recortando intervalo [\"" + descInicio + "\", \"" + descFim + "\"]...\n");
        Lista<Produto> resultadoDesc = abbDesc.recortar(descInicio, descFim);
        
        // Mostrar apenas primeiros 20 itens
        String[] linhas = resultadoDesc.toString().split("\n");
        for (int i = 0; i < Math.min(20, linhas.length); i++) {
            System.out.println(linhas[i]);
        }
        if (linhas.length > 20) {
            System.out.println("... (mais " + (linhas.length - 20) + " produtos)\n");
        }
        
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║  ✓ Ambas as opções funcionando corretamente!                    ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝\n");
    }
}
