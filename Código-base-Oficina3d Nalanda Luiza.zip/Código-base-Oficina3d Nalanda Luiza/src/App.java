import java.nio.charset.Charset;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.function.Function;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class App {

	/** Nome do arquivo de dados. O arquivo deve estar localizado na raiz do projeto */
    static String nomeArquivoDados;
    
    /** Scanner para leitura de dados do teclado */
    static Scanner teclado;

    /** Quantidade de produtos cadastrados atualmente na lista */
    static int quantosProdutos = 0;

    static ABB<String, Produto> produtosCadastradosPorNome;
    
    static ABB<Integer, Produto> produtosCadastradosPorId;
    
    static AVL<String, Produto> produtosBalanceadosPorNome;
    
    static AVL<Integer, Produto> produtosBalanceadosPorId;
    
    static void limparTela() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    /** Gera um efeito de pausa na CLI. Espera por um enter para continuar */
    static void pausa() {
        System.out.println("Digite enter para continuar...");
        try {
            if (teclado.hasNextLine()) {
                teclado.nextLine();
            }
        } catch (NoSuchElementException e) {
        }
    }

    /** Cabeçalho principal da CLI do sistema */
    static void cabecalho() {
        System.out.println("AEDs II COMÉRCIO DE COISINHAS");
        System.out.println("=============================");
    }
   
    static <T extends Number> T lerOpcao(String mensagem, Class<T> classe) {
        
    	T valor;
        
    	System.out.println(mensagem);
    	try {
            valor = classe.getConstructor(String.class).newInstance(teclado.nextLine());
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException 
        		| InvocationTargetException | NoSuchMethodException | SecurityException e) {
            return null;
        }
        return valor;
    }
    
    /** Imprime o menu principal, lê a opção do usuário e a retorna (int).
     * Perceba que poderia haver uma melhor modularização com a criação de uma classe Menu.
     * @return Um inteiro com a opção do usuário, ou -1 em caso de EOF.
    */
    static int menu() {
        cabecalho();
        System.out.println("1 - Carregar produtos por nome/descrição");
        System.out.println("2 - Carregar produtos por id");
        System.out.println("3 - Procurar produto, por nome");
        System.out.println("4 - Procurar produto, por id");
        System.out.println("5 - Remover produto, por nome");
        System.out.println("6 - Remover produto, por id");
        System.out.println("7 - Recortar a lista de produtos, por nome");
        System.out.println("8 - Recortar a lista de produtos, por id");
        System.out.println("9 - Testar recorte por nome");
        System.out.println("0 - Sair");
        System.out.print("Digite sua opção: ");
        try {
            if (teclado.hasNextLine()) {
                String linha = teclado.nextLine();
                return Integer.parseInt(linha);
            } else {
                return -1; // EOF
            }
        } catch (NoSuchElementException | NumberFormatException e) {
            return -1;
        }
    }
    
    /**
     * Lê os dados de um arquivo-texto e retorna uma árvore de produtos. Arquivo-texto no formato
     * N (quantidade de produtos) <br/>
     * tipo;descrição;preçoDeCusto;margemDeLucro;[dataDeValidade] <br/>
     * Deve haver uma linha para cada um dos produtos. Retorna uma árvore vazia em caso de problemas com o arquivo.
     * @param nomeArquivoDados Nome do arquivo de dados a ser aberto.
     * @return Uma árvore com os produtos carregados, ou vazia em caso de problemas de leitura.
     */
    static <K> ABB<K, Produto> lerProdutos(String nomeArquivoDados, Function<Produto, K> extratorDeChave) {
    	
    	Scanner arquivo = null;
    	int numProdutos;
    	String linha;
    	Produto produto;
    	ABB<K, Produto> produtosCadastrados;
    	K chave;
    	
    	try {
        		arquivo = new Scanner(new File(nomeArquivoDados), "UTF-8");
    		
            numProdutos = Integer.parseInt(arquivo.nextLine());
            produtosCadastrados = new AVL<K, Produto>();    		for (int i = 0; i < numProdutos; i++) {
    			linha = arquivo.nextLine();
    			produto = Produto.criarDoTexto(linha);
    			chave = extratorDeChave.apply(produto);
    			produtosCadastrados.inserir(chave, produto);
    		}
    		quantosProdutos = numProdutos;
    		
    	} catch (IOException excecaoArquivo) {
    		produtosCadastrados = null;
    	} finally {
    		arquivo.close();
    	}
    	
    	return produtosCadastrados;
    }

    static class CarregamentoResult<K> {
        ABB<K, Produto> arvore;
        java.util.List<K> chaves;
        long tempoInsercaoMs;
        int quantidade;
    }

    static <K> CarregamentoResult<K> lerProdutosMedido(String nomeArquivoDados, java.util.function.Function<Produto, K> extratorDeChave, boolean usarAVL) {
        Scanner arquivo = null;
        int numProdutos;
        String linha;
        Produto produto;
        ABB<K, Produto> produtosCadastrados;
        K chave;
        CarregamentoResult<K> resultado = new CarregamentoResult<>();
        resultado.chaves = new java.util.ArrayList<>();

        try {
                arquivo = new Scanner(new File(nomeArquivoDados), "UTF-8");

            numProdutos = Integer.parseInt(arquivo.nextLine());
            if (usarAVL)
                produtosCadastrados = new AVL<K, Produto>();
            else
                produtosCadastrados = new ABB<K, Produto>();

            long inicio = System.nanoTime();
            for (int i = 0; i < numProdutos; i++) {
                linha = arquivo.nextLine();
                produto = Produto.criarDoTexto(linha);
                chave = extratorDeChave.apply(produto);
                produtosCadastrados.inserir(chave, produto);
                resultado.chaves.add(chave);
            }
            long termino = System.nanoTime();
            resultado.arvore = produtosCadastrados;
            resultado.tempoInsercaoMs = (termino - inicio) / 1_000_000;
            resultado.quantidade = numProdutos;

            quantosProdutos = numProdutos;

        } catch (IOException excecaoArquivo) {
            resultado.arvore = null;
            resultado.tempoInsercaoMs = -1;
            resultado.quantidade = 0;
        } finally {
            if (arquivo != null)
                arquivo.close();
        }

        return resultado;
    }

    static void carregarECompararPorId() {
        System.out.println("Carregando produtos em ABB (por id)...");
        CarregamentoResult<Integer> resAbb = lerProdutosMedido(nomeArquivoDados, (p -> p.idProduto), false);
        System.out.println("Tempo de inserção ABB: " + resAbb.tempoInsercaoMs + " ms");

        System.out.println("Carregando produtos em AVL (por id)...");
        CarregamentoResult<Integer> resAvl = lerProdutosMedido(nomeArquivoDados, (p -> p.idProduto), true);
        System.out.println("Tempo de inserção AVL: " + resAvl.tempoInsercaoMs + " ms");

        produtosCadastradosPorId = resAbb.arvore;
        produtosBalanceadosPorId = (AVL<Integer, Produto>) resAvl.arvore;

        java.util.List<Integer> amostra = resAbb.chaves;
        int tamanhoAmostra = Math.min(1000, amostra.size());
        java.util.Random rnd = new java.util.Random(0);
        java.util.List<Integer> chavesTeste = new java.util.ArrayList<>(tamanhoAmostra);
        for (int i = 0; i < tamanhoAmostra; i++) {
            chavesTeste.add(amostra.get(rnd.nextInt(amostra.size())));
        }

        long inicioAbb = System.nanoTime();
        for (Integer k : chavesTeste) {
            try {
                produtosCadastradosPorId.pesquisar(k);
            } catch (Exception e) {
            }
        }
        long terminoAbb = System.nanoTime();
        long totalAbbMs = (terminoAbb - inicioAbb) / 1_000_000;

        long inicioAvl = System.nanoTime();
        for (Integer k : chavesTeste) {
            try {
                produtosBalanceadosPorId.pesquisar(k);
            } catch (Exception e) {
            }
        }
        long terminoAvl = System.nanoTime();
        long totalAvlMs = (terminoAvl - inicioAvl) / 1_000_000;

        System.out.println("--- Comparação de busca por ID (" + tamanhoAmostra + " buscas) ---");
        System.out.println("Tempo total ABB: " + totalAbbMs + " ms | média: " + (double) totalAbbMs / tamanhoAmostra + " ms/busca");
        System.out.println("Tempo total AVL: " + totalAvlMs + " ms | média: " + (double) totalAvlMs / tamanhoAmostra + " ms/busca");
    }

    static void testarRecortarPorNome() {
        System.out.println("Carregando ABB por nome (teste recortar)...");
        String arquivo = (nomeArquivoDados == null || nomeArquivoDados.isEmpty()) ? "produtos.txt" : nomeArquivoDados;
        CarregamentoResult<String> res = lerProdutosMedido(arquivo, (p -> p.descricao), false);
        ABB<String, Produto> abb = res.arvore;
        System.out.println("Tempo de insercao ABB (ms): " + res.tempoInsercaoMs);

        if (res.chaves == null || res.chaves.isEmpty()) {
            System.out.println("Nenhuma chave carregada para teste.");
            return;
        }

        String inicio = res.chaves.get(0);
        String fim = res.chaves.size() > 10 ? res.chaves.get(10) : res.chaves.get(res.chaves.size() - 1);

        System.out.println("Recortando intervalo de descricoes: \"" + inicio + "\" a \"" + fim + "\"");
        Lista<Produto> lista = abb.recortar(inicio, fim);
        System.out.println("Resultado do recorte (toString da Lista):");
        System.out.println(lista);

        System.out.println("Recortando intervalo invertido:");
        Lista<Produto> listaInvertida = abb.recortar(fim, inicio);
        System.out.println(listaInvertida);
    }
    
    static <K> Produto localizarProduto(ABB<K, Produto> produtosCadastrados, K procurado) {
    	
    	Produto produto;
    	
    	cabecalho();
    	System.out.println("Localizando um produto...");
    	
    	try {
    		produto = produtosCadastrados.pesquisar(procurado);
    	} catch (NoSuchElementException excecao) {
    		produto = null;
    	}
    	
    	System.out.println("Número de comparações realizadas: " + produtosCadastrados.getComparacoes());
    	System.out.println("Tempo de processamento da pesquisa: " + produtosCadastrados.getTempo() + " ms");
        
    	return produto;
    	
    }
    
    /** Localiza um produto na árvore de produtos organizados por id, a partir do código de produto informado pelo usuário, e o retorna. 
     *  Em caso de não encontrar o produto, retorna null */
    static Produto localizarProdutoID(ABB<Integer, Produto> produtosCadastrados) {
        
        int idProduto = lerOpcao("Digite o identificador do produto desejado: ", Integer.class);
        
        return localizarProduto(produtosCadastrados, idProduto);
    }
    
    /** Localiza um produto na árvore de produtos organizados por nome, a partir do nome de produto informado pelo usuário, e o retorna. 
     *  A busca não é sensível ao caso. Em caso de não encontrar o produto, retorna null */
    static Produto localizarProdutoNome(ABB<String, Produto> produtosCadastrados) {
        
    	String descricao;
    	
    	System.out.println("Digite o nome ou a descrição do produto desejado:");
        descricao = teclado.nextLine();
        
        return localizarProduto(produtosCadastrados, descricao);
    }
    
    private static void mostrarProduto(Produto produto) {
    	
        cabecalho();
        String mensagem = "Dados inválidos para o produto!";
        
        if (produto != null){
            mensagem = String.format("Dados do produto:\n%s", produto);
        }
        
        System.out.println(mensagem);
    }
    
    /** Localiza e remove um produto da árvore de produtos organizados por id, a partir do código de produto informado pelo usuário, e o retorna. 
     *  Em caso de não encontrar o produto, retorna null */
    static Produto removerProdutoId(ABB<Integer, Produto> produtosCadastrados) {
         cabecalho();
         System.out.println("Localizando o produto por id");
         int id = lerOpcao("Digite o id do produto que deve ser removido", Integer.class);
         Produto localizado =  removerProduto(produtosCadastrados, id);
         return localizado;
    }

     /** Localiza e remove um produto na árvore de produtos organizados por nome, a partir do nome de produto informado pelo usuário, e o retorna. 
      *  A busca não é sensível ao caso. Em caso de não encontrar o produto, retorna null */
    static Produto removerProdutoNome(ABB<String, Produto> produtosCadastrados) {
    	String descricao;
         
    	cabecalho();
        System.out.println("Localizando o produto por nome");
        System.out.print("Digite a descrição do produto que deve ser removido: ");
        descricao = teclado.nextLine();
        Produto localizado =  removerProduto(produtosCadastrados, descricao);
        return localizado;
    }

    static <K> Produto removerProduto(ABB<K, Produto> produtosCadastrados, K chave){
         cabecalho();
         Produto localizado =  produtosCadastrados.remover(chave);
         return localizado;
    }
    
    static <K> void recortarGenerico(ABB<K, Produto> produtosCadastrados, String descricaoChave, Class<K> classeChave) {
        if (produtosCadastrados == null) {
            System.out.println("Nenhuma árvore carregada para recorte!");
            return;
        }
        
        cabecalho();
        System.out.println("Recortar produtos por " + descricaoChave);
        
        K chaveInicio;
        K chaveFim;
        
        try {
            if (classeChave == Integer.class) {
                System.out.print("Digite o " + descricaoChave + " inicial: ");
                if (!teclado.hasNextLine()) {
                    System.out.println("Entrada não disponível (EOF)");
                    return;
                }
                chaveInicio = (K) (Integer) Integer.parseInt(teclado.nextLine());
                System.out.print("Digite o " + descricaoChave + " final: ");
                if (!teclado.hasNextLine()) {
                    System.out.println("Entrada não disponível (EOF)");
                    return;
                }
                chaveFim = (K) (Integer) Integer.parseInt(teclado.nextLine());
            } else if (classeChave == String.class) {
                System.out.print("Digite o " + descricaoChave + " inicial: ");
                if (!teclado.hasNextLine()) {
                    System.out.println("Entrada não disponível (EOF)");
                    return;
                }
                chaveInicio = (K) teclado.nextLine();
                System.out.print("Digite o " + descricaoChave + " final: ");
                if (!teclado.hasNextLine()) {
                    System.out.println("Entrada não disponível (EOF)");
                    return;
                }
                chaveFim = (K) teclado.nextLine();
            } else {
                System.out.println("Tipo de chave não suportado.");
                return;
            }
        } catch (NoSuchElementException | NumberFormatException e) {
            System.out.println("Erro ao ler entrada: " + e.getMessage());
            return;
        }
        
        Lista<Produto> resultado = produtosCadastrados.recortar(chaveInicio, chaveFim);
        
        System.out.println("\n--- Resultado do recorte ---");
        if (resultado == null || resultado.toString().isEmpty()) {
            System.out.println("Nenhum produto encontrado no intervalo especificado.");
        } else {
            System.out.println(resultado);
        }
    }
    
    private static void recortarProdutosNome(ABB<String, Produto> produtosCadastrados) {
        recortarGenerico(produtosCadastrados, "descrição", String.class);
    }
     
    private static void recortarProdutosId(ABB<Integer, Produto> produtosCadastrados) {
        recortarGenerico(produtosCadastrados, "ID", Integer.class);
    }
    
	public static void main(String[] args) {
        teclado = new Scanner(System.in, "UTF-8");
        nomeArquivoDados = "produtos.txt";
        
        int opcao = -1;
      
        do{
            opcao = menu();
            switch (opcao) {
                case 1:
                    produtosCadastradosPorNome = lerProdutos(nomeArquivoDados, (p -> p.descricao));
                    break;
                case 2:
                    carregarECompararPorId();
                    break;
                case 3:
                    mostrarProduto(localizarProdutoNome(produtosCadastradosPorNome));
                    break;
                case 4:
                    mostrarProduto(localizarProdutoID(produtosCadastradosPorId));
                    break;
                case 5:
                    mostrarProduto(removerProdutoNome(produtosCadastradosPorNome));
                    break;
                case 6:
                    mostrarProduto(removerProdutoId(produtosCadastradosPorId));
                    break;
                case 7:
                    recortarProdutosNome(produtosCadastradosPorNome);
                    break;
                case 8:
                    recortarProdutosId(produtosCadastradosPorId);
                    break;
                case 9:
                    testarRecortarPorNome();
                    break;
                default:
                    break;
            }
            if (opcao != 0 && opcao != -1) {
                pausa();
            }
        }while(opcao != 0 && opcao != -1);       

        teclado.close();    
    }
}
