/**
 * Teste das funções de recorte por nome e por ID
 */
public class TestRecortarMenu {
    public static void main(String[] args) {
        System.out.println("=== TESTE DE RECORTE POR ID ===\n");
        
        // Carregar produtos por ID
        System.out.println("Carregando produtos por ID...");
        App.CarregamentoResult<Integer> resId = App.lerProdutosMedido("produtos.txt", (p -> p.idProduto), false);
        
        if (resId.arvore == null) {
            System.out.println("Falha ao carregar árvore por ID!");
            return;
        }
        
        System.out.println("Tempo de inserção: " + resId.tempoInsercaoMs + " ms");
        System.out.println("Produtos carregados: " + resId.quantidade);
        
        // Testar recorte por ID
        System.out.println("\n--- Recortando intervalo [10000, 10010] ---");
        Lista<Produto> resultadoId = resId.arvore.recortar(10000, 10010);
        System.out.println(resultadoId);
        
        System.out.println("\n\n=== TESTE DE RECORTE POR DESCRIÇÃO ===\n");
        
        // Carregar produtos por descrição
        System.out.println("Carregando produtos por descrição...");
        App.CarregamentoResult<String> resDesc = App.lerProdutosMedido("produtos.txt", (p -> p.descricao), false);
        
        if (resDesc.arvore == null) {
            System.out.println("Falha ao carregar árvore por descrição!");
            return;
        }
        
        System.out.println("Tempo de inserção: " + resDesc.tempoInsercaoMs + " ms");
        System.out.println("Produtos carregados: " + resDesc.quantidade);
        
        // Testar recorte por descrição
        if (resDesc.chaves != null && resDesc.chaves.size() > 0) {
            String inicio = resDesc.chaves.get(0);
            String fim = resDesc.chaves.size() > 100 ? resDesc.chaves.get(100) : resDesc.chaves.get(resDesc.chaves.size() - 1);
            
            System.out.println("\n--- Recortando intervalo [\"" + inicio + "\", \"" + fim + "\"] ---");
            Lista<Produto> resultadoDesc = resDesc.arvore.recortar(inicio, fim);
            System.out.println("Resultado (primeiros 15 itens):");
            
            // Imprimir apenas 15 primeiros itens
            String[] linhas = resultadoDesc.toString().split("\n");
            for (int i = 0; i < Math.min(15, linhas.length); i++) {
                System.out.println(linhas[i]);
            }
            if (linhas.length > 15) {
                System.out.println("... (" + (linhas.length - 15) + " itens adicionais)");
            }
        }
    }
}
