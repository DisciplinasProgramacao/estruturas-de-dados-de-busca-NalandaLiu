public class TestRecortarNome {
    public static void main(String[] args) {
        App.testarRecortarPorNome();
    }
}
